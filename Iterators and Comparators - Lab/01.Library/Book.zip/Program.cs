﻿namespace IteratorsAndComparators;

Book books = new Book("C# for Begginers", 2021, "Peter,Gosho");